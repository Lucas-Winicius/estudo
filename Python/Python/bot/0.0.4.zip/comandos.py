import discord
from discord.ext import commands
from random import randint
from time import sleep

client = commands.Bot(command_prefix='>', case_insensitive=True)


async def ola(ctx):
  await ctx.send(f'Olá, {ctx.author}')