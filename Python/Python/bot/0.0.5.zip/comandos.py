from random import randint

