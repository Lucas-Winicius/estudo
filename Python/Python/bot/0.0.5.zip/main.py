import discord
from discord.ext import commands
from random import randint, choice
from time import sleep
from datetime import *
import os

adivinhe = ['abobora', 'melão']

data = ''


intents = discord.Intents.default()
intents.members = True

client = commands.Bot(command_prefix='>', case_insensitive=True)

@client.event
async def on_ready():
  print('Entramos como {0.user}'.format(client))

# NÃO ESTA FUNCIONANDO
@client.event
async def on_member_join(member):
  print('EXECUTANDO...')
  canal_boas_vindas = client.get_channel(939350630785507359)
  regras = client.get_channel(713066571609931796)
  mensagem = await canal_boas_vindas.send(f'<:emoji_17:834904386911076424>Olá, {member.mention}! Leia as regras em {regras}')

@client.event
async def oie(ctx):
  zois(ctx)

@client.command()
async def ola(ctx):
  await ctx.send(f'Olá, {ctx.author}')

@client.command()
async def dado(ctx, numero=6):
  v = randint(1, int(numero))
  await ctx.send('Girando dado...')
  sleep(2.3)
  await ctx.send(f'DADO: {v}')

@client.command()
async def game(ctx, numero=0):
  await ctx.send('Iniciando game...')
  vct = False
  sleep(1)
  await ctx.send('Isso pode demorar um pouco aguarde')
  sleep(4)
  comp = 25
  await ctx.send('>j "sua jogada"')
  while vct != True:
    @client.command()
    async def jogada(ctx, jog):
      play = int(jog)
      if play < 0 and play > 50:
        await ctx.send('Numero invalido!')
      if play == comp:
        await ctx.send('Vitoria!')
        vct = True

  await ctx.send('Jogo finalizado')

@client.command()
async def adivinhe(ctx):
  a = choice(adivinhe)
  await ctx.send(a)


@client.command()
async def Comando(ctx):
  await ctx.send(file=discord.File('load.jpg'))

@client.command()
async def finalizar(ctx):
  await ctx.send('Finalizando BOT...')
  sleep(7)
  await ctx.send('AGUARDE...')
  sleep(9)
  await ctx.send('Isso esta demorando mais que o esperado.')
  sleep(11)
  await ctx.send('BOT finalizado com sucesso!')

@client.command()
async def ping(ctx):
  await ctx.send(f"PONG! {round(client.latency * 1000)}ms")

@client.command()
async def ajuda(ctx):
  await ctx.send(file=discord.File('load.jpg'))

@client.command()
async def fig(ctx):
  await ctx.send('<:emoji_19:834904563702038529> <:emoji_16:834904337028481074> <:emoji_2:834892118039592980> <:emoji_21:834904681569583125>')

@client.command()
async def ma(ctx):
  pedro = client.get_user(785497461207859221)
  await ctx.author.send(f'Comando temporario sugerido por {pedro}.')
  sleep(2)
  await ctx.author.send('Mama eu')
  sleep(1)
  await ctx.author.send(';-;')

@client.command()
async def e(ctx):
  embed = discord.Embed(
    title = 'TITULO',
    description = 'Descrição',
    colour = 16711680
  )

  embed.set_author(name='Criador: ABOBORA', icon_url='https://www.tibiawiki.com.br/images/5/5c/Mining_Helmet.gif')

  embed.set_thumbnail(url='https://www.tibiawiki.com.br/images/c/ce/The_Epic_Wisdom.gif')

  embed.set_image(url='https://www.minecraft.net/content/dam/games/minecraft/marketplace/updates-catspandas_latest.jpg')

  embed.set_footer(text='Footer')

  embed.add_field(name='Nome', value='VALOR', inline=True)
  embed.add_field(name='Nome', value='VALOR', inline=True)
  embed.add_field(name='Nome', value='VALOR', inline=True)
  await ctx.send(embed = embed)

@client.command()
async def hora(ctx):
  data = str(f'{datetime.today().day}/{datetime.today().month}/{datetime.today().year}  {datetime.today().hour}:{datetime.today().minute}')
  await ctx.send(data)
  await ctx.send(f'Bot online desde {data}')

@client.command()
async def comandos(ctx):
  data = str(f'{datetime.today().day}/{datetime.today().month}/{datetime.today().year}  {datetime.today().hour}:{datetime.today().minute}')

  comandos = discord.Embed(
    title = 'Lista de comandos:',
    description = 'Lembre-se de sempre colocar ">" para o comando ser executado',
    colour = 16729600
  )

  comandos.set_author(name='Abobora')#, icon_url='https://i.imgur.com/pxirbXg.jpg')

  comandos.set_thumbnail(url='https://c.tenor.com/15iA-FBQhuAAAAAd/pumpkin-dancing-pumpkin.gif')

  comandos.add_field(name='OLA', value=f'Te da um oizinho {os.linesep} ', inline=False)
  comandos.add_field(name='DADO "Valor"', value=f'Retorna um numero aleatorio contando desde o 1 ate o seu numero escolhido {os.linesep} ', inline=False)
  comandos.add_field(name='PING', value=f'Exibe o atual ping do Bot {os.linesep} ', inline=False)
  comandos.add_field(name='HORA', value=f'Mostra o horario atual do servidor{os.linesep} ', inline=False)

  comandos.set_footer(text= data)

  await ctx.send(embed= comandos)
  sleep(3)
  await ctx.send('''comandos:

Funções Ativas:
!Bot em funcionamento
!novo Membro #apresenta erro

Comandos:
>oie #indisponivel
>ola
>dado 99 
>game #em desenvolvimento
    >jogada #funcionalidade extra do >game
>adivinhe #jogo de adivinhaçao incompleto
>comandos #criar um embed 
>finalizar #reinicia o Bot
>ping
>ajuda
>e
>fig
>comand

Versão 0.0.5

V0.0.6
Limpar o codigo
''')

client.run('OTM2NzgyODAyOTQ1NDY2Mzg4.YfSM-A.kIxvTZR8ZY6-CG9QboncdWvIbEE')
